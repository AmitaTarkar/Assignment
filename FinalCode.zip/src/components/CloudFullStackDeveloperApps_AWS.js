const CloudFullStackDeveloperApps_AWS = () => {
    return (
        <div className="tab-pane fade" id="v-pills-profile-apps" role="tabpanel"
            aria-labelledby="v-pills-profile-tab-apps">

            <div className="card-body">
                <div className="tab-table table-responsive">

                    <table className="table">
                        <thead>
                            <tr>
                                {/*  {/* <!--      <th scope="col">#</th>--> */}

                                <td className="table-td"><b>Proficiency</b></td>
                                <td className="table-td">Beginner</td>

                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                {/*  {/* <!--      <th scope="row">1</th>--> */}
                                <td><b>Course Duration:</b></td>
                                <td>70+ hours</td>
                            </tr>
                            <tr>
                                {/*  {/* <!--      <th scope="row">2</th>--> */}
                                <td><b>Experience:</b></td>
                                <td>
                                    <ol>
                                        <li>Trained in these skills</li>
                                        <li>Conceptual knowledge across all</li>
                                        <li>0-2 years hands-on experience</li>
                                    </ol>
                                </td>
                            </tr>
                            <tr>
                                {/*  {/* <!--      <th scope="row">3</th>--> */}
                                <td><b>Employee Grade</b></td>
                                <td>A, B, c</td>
                            </tr>
                            <tr>
                                {/*  {/* <!--      <th scope="row">3</th>--> */}
                                <td><b>Professional Certification:</b></td>
                                <td>AZ 900 - Azure Foundation</td>
                            </tr>
                            <tr>
                                {/*  {/* <!--      <th scope="row">3</th>--> */}
                                <td><b>Internal Certification:</b><br />(Capgemini Standard
                                    Certification)</td>
                                <td>Not aplicable</td>
                            </tr>
                            <tr>
                                {/*  {/* <!--      <th scope="row">3</th>--> */}
                                <td><b>What will you learn?</b><br />(Mandatory skills)</td>
                                <td>
                                    <ol>
                                        <li>Programming Languages - e.g. C#, .net, .Net Core etc.
                                        </li>
                                        <li>JavaScript-Frameworks - e.g. Angular,React etc.</li>
                                        <li>Database Knowledge - e.g. SQL/NoSQL<br />RESTAPI</li>
                                        <li>Cloud Computing with the knowledge of any Public Cloud -
                                            e.e. Azure/AWS/Google</li>
                                        <li>Should be certified on Professional Certificate</li>
                                    </ol>
                                </td>
                            </tr>
                            <tr>
                                {/*  {/* <!--      <th scope="row">3</th>--> */}
                                <td><b>What will you learn?</b><br />(Good to Have Skills)</td>
                                <td>
                                    <ol>
                                        <li>Introduction to Cloud Migrations - Methodologies and
                                            tools</li>
                                        <li>TDD</li>
                                        <li>Microservices fundamentals</li>
                                        <li>Development Tools and IDE</li>
                                        <li>Knowledge of DevOps Tools</li>
                                        <li>Strong understanding of Agile development</li>
                                        <li>Understanding of software testing and optimization
                                            methodologies</li>
                                        <li>Creating rich documentaion for software solutions</li>
                                        <li>Should be certified with internal Certificates if any
                                        </li>
                                    </ol>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>

            </div>

        </div>
    );

}
export default CloudFullStackDeveloperApps_AWS;