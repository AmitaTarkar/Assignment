import React, { Component } from "react";
import { Accordion, Card } from "react-bootstrap";
import { useAccordionButton } from 'react-bootstrap/AccordionButton';

// import '../css_allstyles/bootstrap.min.css';

// 

// export default AccordionRole;

import rolesSelection from "./RoleAccordData";
function CustomToggle({ children, eventKey }) {
    const decoratedOnClick = useAccordionButton(eventKey, () =>
        console.log('totally custom!'),
    );

    return (
        <div

            onClick={decoratedOnClick}
        >
            {children}
        </div>
        // { children }
    );
}

function AccordionRole(props) {
    // const rc = rolesSelection.Map()
    // alert(props.roles);
    // alert(props.name);
    // const setlink = rolesSelection.Map((e) => {
    //     return (
    //         e.roles.map((a) => { return (a.rolename) })

    //     )
    // });
    return (


        <Accordion >
            <Card>
                <Card.Header>
                    <CustomToggle eventKey="0">{props.name}</CustomToggle>
                </Card.Header>
                <Accordion.Collapse eventKey="0">
                    <Card.Body>
                        {/* foreach(item in abc){
                            <li>item.rolename</li>
                        } */}

                        {/* {props.id} */}
                        {/* {props.rolename} */}


                    </Card.Body>
                </Accordion.Collapse>
            </Card>
        </Accordion>
    )


}
export default AccordionRole;