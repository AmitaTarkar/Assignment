import { BrowserRouter as Router, Routes,     Route, Redirect,} from "react-router-dom";

import { Navbar } from 'react-bootstrap';
import AccordionRole from './components/AccordionRole';
import NavBar from './components/NavBar';
import RolesWorking from './components/RolesWorking';
import './css_allstyles/all.min.css';
import './css_allstyles/apply.css';
import './css_allstyles/bootstrap.min.css';
import './css_allstyles/grayscale.min.css';
import './css_allstyles/sp-nav-edit1.css';

function App() {
  return (
    <div>
{/* <Routes >
      
      <Route component={Navbar} path='/' />
      
    </Routes> */}
      {/* <NavBar /> */}
      <Routes>
        <Route path="/" element={<NavBar />} />
        <Route path="/NavToRole" element={<RolesWorking  />} />
        {/* <Route path="/NavToRole" element={<NavBar navTo={"Roles"} />} /> */}
      </Routes>
      {/* <AccordionRole /> */}
    </div >
  );
}

export default App;
