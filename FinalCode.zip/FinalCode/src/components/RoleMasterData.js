const rolesMasterData=()=>{
    const rolesMaster = [
        {
          "role": "Proficiency",
          "rolesTypes": [{
            "name": "Expert",
            "type": "text"
          }, {
            "name": "Intermediate",
            "type": "text"
          }, {
            "name": "Beginner",
            "type": "text"
          }]
        },
        {
          "role": "Apps Roles",
          "rolesTypes": [{
            "name": ["AWS DevOps Expert - Apps", "AWS Solution Architect - Apps"],
            "type": "bullet"
          }, {
            "name": ["Cloud Full stack Developer - Apps (AWS)"],
            "type": "bullet"
          }, {
            "name": ["Developer - Apps (AWS)"],
            "type": "bullet"
          }]
        },
        {
          "role": "Infra Roles",
          "rolesTypes": [{
            "name": ["AWS DevOps Expert", "AWS Solution Architect - Infra"],
            "type": "bullet"
          }, {
            "name": ["AWS Cloud SysOps Lead", "AWS DevOps Analyst", "AWS Cloud Architect"],
            "type": "bullet"
          }, {
            "name": ["AWS Cloud Engineer"],
            "type": "bullet"
          }]
        },
        {
          "role": "Data Roles",
          "rolesTypes": []
        }
      ]
      
      const rolesMasterListing = [
        {
          "role": "Apps Roles",
          "rolesTypes": ["AWS DevOps Expert - Apps", "AWS Solution Architect - Apps", "Cloud Full stack Developer - Apps (AWS)", "Developer - Apps (AWS)"],
        },
        {
          "role": "Infra Roles",
          "rolesTypes": ["one","two","three"]
        },
        {
          "role": "Data Roles",
          "rolesTypes": ["four","five","six"]
        }
      ]
      
      let roleObject = {
        "role": "Apps Roles",
        "currentRole":"AWS DevOps Expert - Apps"
      }
}

export default rolesMasterData;