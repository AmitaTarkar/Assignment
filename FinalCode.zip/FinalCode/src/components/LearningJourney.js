import { useNavigate, Link } from "react-router-dom";
// import {Routes, Route, useNavigate,Navigate} from 'react-router-dom';

    import React, { useCallback, useState } from "react";
// import { Link, Router, Route, Redirect } from 'react-router-dom';
// import { HashLink as Link } from 'react-router-hash-link';
import Roles from './Roles';
// import { redirect } from 'react-router';
// import { BrowserRouter as Router, Routes,     Route, Redirect,} from "react-router-dom";
import RolesWorking from "./RolesWorking";
import NavBar from "./NavBar";
const LearningJourney = () => {
    {
        const navigate = useNavigate();

  const navigateToContacts = () => {
    console.log("navigate...");
    //  navigate('/RolesWorking');
    // <Link to "/NavtoRole"/>    
};
// function handleClick() {
//     window.location.href = ("/NavToRole");
//   }
 
        return (
            
            <div className="container-fluid">
                <div className="tab-content" id="pills-tabContent">
                    <div className="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">
                        <section id="" className="text-center">
                            <div className="container-fluid">
                                <div className="row">
                                    <div className="col-lg-12">
                                        <div className="row">
                                            <div className="col-lg-3">
                                                <div className="skill-header">Proficiency</div>
                                                <div className="prof-expert"><strong>Expert</strong></div>
                                                <div className="prof-intermediate"><strong>Intermediate</strong></div>
                                                <div className="prof-beginner"><strong>Beginner</strong></div>
                                            </div>

                                            <div className="col-lg-3">
                                                <div className="skill-header">Apps Roles</div>
                                                <div className="apps-role prof-expert roles">
                                                    <ul>
                                                        <a href="aws-pages/aws-apps-devops-expert.html">
                                                            <li>AWS DevOps Expert - Apps</li>
                                                        </a>
                                                        <a href="aws-pages/aws-apps-solution-architect.html">
                                                            <li>AWS Solution Architect - Apps</li>
                                                        </a>
                                                    </ul>
                                                </div>
                                                <div className="apps-role prof-intermediate roles">
                                                    <ul>
                                                        <a href="aws-pages/aws-apps-cloud-fullstack.html">
                                                            <li>Cloud Full Stack Developer - Apps (AWS)</li>
                                                        </a>
                                                    </ul>
                                                </div>
                                                <div className="apps-role prof-beginner roles">
                                                    <ul>
                                                    {/* <Link to="/NavtoRole" navTo="Roles">Developer - Apps (AWS)</Link> */}
                {/*<Router> <Routes><Route path="/#v-pills-home-apps" component={RolesWorking} >  */}
                                                        <a href="#v-pills-home-apps" id="v-pills-home-tab-apps" >
                                                            <li  >Developer - Apps (AWS)</li>
                                                            {/* <li onClick={handleClick} >Developer - Apps (AWS)</li> */}
                                                        </a>
                                                        {/* </Route>  </Routes>            </Router> */}
                                                        {/* <Link to="#v-pills-home-apps"><li>Developer - Internal Certification:Apps (AWS)</li></Link> */}
                                                        {/* <li onClick={() => window.location.replace("/#v-pills-home-apps")}>Developer - Apps (AWS)</li> */}
                                                        {/* <li onClick={NavtoRole}>Developer - Apps (AWS)</li> */}
{/* <a onClick={() => {
                        navTo("Roles")}}><li>Developer - Apps (AWS)</li></a> */}
                                        {/* <a onClick={<RolesWorking id="v-pills-home-tab-apps"/>}>
                                                            <li>Developer - Apps (AWS)</li>
                                                        </a> */}
                                                        {/* <button onClick={navigateToContacts}>Login</button> */}
                                                    </ul>
                                                </div>
                                            </div>
                                            <div className="col-lg-3">
                                                <div className="skill-header">Infra Roles</div>
                                                <div className="infra-role prof-expert roles">

                                                    <ul>
                                                        <a href="aws-pages/aws-infra-devops-expert.html">
                                                            <li>AWS DevOps Expert</li>
                                                        </a>
                                                        <a href="aws-pages/aws-infra-solution-architect.html">
                                                            <li>AWS Solution Architect - Infra</li>
                                                        </a>
                                                    </ul>

                                                </div>
                                                <div className="infra-role prof-intermediate roles">
                                                    <ul>
                                                        <a href="aws-pages/aws-infra-cloud-sysopslead.html">
                                                            <li>AWS Cloud SysOps Lead</li>
                                                        </a>
                                                        <a href="aws-pages/aws-infra-devops-analyst.html">
                                                            <li>AWS DevOps Analyst</li>
                                                        </a>
                                                        <a href="aws-pages/aws-infra-cloud-architect.html">
                                                            <li>AWS Cloud Architect</li>
                                                        </a>
                                                    </ul>
                                                </div>
                                                <div className="infra-role prof-beginner roles">
                                                    <ul>
                                                        <a href="aws-pages/aws-infra-cloud-engineer.html">
                                                            <li>AWS Cloud Engineer</li>
                                                        </a>
                                                    </ul>
                                                </div>
                                            </div>
                                            <div className="col-lg-3">
                                                <div className="skill-header">Data Roles</div>
                                                <div className="data-role prof-expert roles">
                                                    <ul>
                                                        <a href="aws-pages/aws-data-cloud-datascientist.html">
                                                            <li>Cloud Data Scientist/Expert- Apps (AWS)</li>
                                                        </a>
                                                        <a href="aws-pages/aws-data-solution-architect.html">
                                                            <li>AWS Data Solution Architect</li>
                                                        </a>
                                                    </ul>
                                                </div>
                                                <div className="data-role prof-intermediate roles">
                                                    <ul>
                                                        <a href="aws-pages/aws-data-senior-engineer.html">
                                                            <li>Senior Data Engineer / Data Engineering Lead</li>
                                                        </a>
                                                    </ul>
                                                </div>
                                                <div className="data-role prof-beginner roles">
                                                    <ul>
                                                        <a href="aws-pages/aws-data-engineer.html">
                                                            <li>Data Engineer</li>
                                                        </a>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>


                                    </div>



                                </div>

                            </div>
                        </section>

                    </div>

                </div >
{/* <div className="outlet">
//{navTo === "roles" ? <RolesWorking/> :<LearningJourney /> }
</div> */}
            </div >

          
        );
    }
}
export default LearningJourney;