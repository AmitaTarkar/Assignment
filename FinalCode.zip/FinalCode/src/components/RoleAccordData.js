// const RoleAccordData = () => {

const rolesSelection = [
    {
        name: "App Roles",
        id: "1",
        roles: [

            {
                id: 1,
                rolename: "AWS DevOps Expert-Apps"
            },
            {
                id: 2,
                rolename: "AWS Solution Architect-Apps"
            },
            {
                id: 3,
                rolename: "Cloud Full Stack Developer-Apps(AWS)"
            },
            {
                id: 4,
                rolename: "Developer-Apps(AWS)"
            }

        ]


    },
    {
        name: "Infra Roles",
        id: "2",
        roles: [

            {
                id: 1,
                rolename: "AWS DevOps Expert"
            },
            {
                id: 2,
                rolename: "AWS Solution Architect - Infra"
            },
            {
                id: 3,
                rolename: "AWS Cloud SysOps Lead"
            },
            {
                id: 4,
                rolename: "AWS DevOps Analyst"
            },
            {
                id: 5,
                rolename: "AWS Cloud Architect"
            },
            {
                id: 6,
                rolename: "AWS Cloud Engineer"
            }
        ]

    }, {
        name: "Data Roles",
        id: "3",
        roles: [

            {
                id: 1,
                rolename: "Cloud Data Scientist/Expert- Apps (AWS)"
            },
            {
                id: 2,
                rolename: "AWS Data Solution Architect"
            },
            {
                id: 3,
                rolename: "Senior Data Engineer / Data Engineering Lead"
            },
            {
                id: 4,
                rolename: "Data Engineer"
            }
        ]

    }

];

export default rolesSelection;