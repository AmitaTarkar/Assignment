const DeveloperApps_AWS = () => {
    return (
        <div className="tab-pane fade show active" id="v-pills-home-apps" role="tabpanel"
            aria-labelledby="v-pills-home-tab-apps">
            <div className="card-body">
                <div className="tab-table table-responsive">
                    <table className="table">
                        <thead>
                            <tr>
                                {/*  {/* <!--      <th scope="col">#</th>--> */}
                                <td className="table-td"><b>Proficiency</b></td>
                                <td className="table-td">Beginner</td>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                {/*  {/* <!--      <th scope="row">1</th>--> */}
                                <td><b>Course Duration:</b></td>
                                <td>70+ hours</td>
                            </tr>
                            <tr>
                                {/*  {/* <!--      <th scope="row">2</th>--> */}
                                <td><b>Experience:</b></td>
                                <td>
                                    <ol>
                                        <li>Trained in these skills</li>
                                        <li>Conceptual knowledge across all</li>
                                        <li>0-2 years hands-on experience</li>
                                    </ol>
                                </td>
                            </tr>
                            <tr>
                                {/*  {/* <!--      <th scope="row">3</th>--> */}
                                <td><b>Employee Grade</b></td>
                                <td>A, B</td>
                            </tr>
                            <tr>
                                {/*  {/* <!--      <th scope="row">3</th>--> */}
                                <td><b>Professional Certification:</b></td>
                                <td>AZ 900 - Azure Foundation</td>
                            </tr>
                            <tr>
                                {/*  {/* <!--      <th scope="row">3</th>--> */}
                                <td><b>Internal Certification:</b><br />(Capgemini Standard
                                    Certification)</td>
                                <td>Not aplicable</td>
                            </tr>
                            <tr>
                                {/*  {/* <!--      <th scope="row">3</th>--> */}
                                <td><b>What will you learn?</b><br />(Mandatory skills)</td>
                                <td>
                                    <ol>
                                        <li>Programming Languages - e.g. C#, .net, .Net Core etc.
                                        </li>
                                        <li>JavaScript-Frameworks - e.g. Angular,React etc.</li>
                                        <li>Database Knowledge - e.g. SQL/NoSQL<br />RESTAPI</li>
                                        <li>Cloud Computing with the knowledge of any Public Cloud -
                                            e.e. Azure/AWS/Google</li>
                                        <li>Should be certified on Professional Certificate</li>
                                    </ol>
                                </td>
                            </tr>
                            <tr>
                                {/*  {/* <!--      <th scope="row">3</th>--> */}
                                <td><b>What will you learn?</b><br />(Good to Have Skills)</td>
                                <td>
                                    <ol>
                                        <li>Introduction to Cloud Migrations - Methodologies and
                                            tools</li>
                                        <li>TDD</li>
                                        <li>Microservices fundamentals</li>
                                        <li>Development Tools and IDE</li>
                                        <li>Knowledge of DevOps Tools</li>
                                        <li>Strong understanding of Agile development</li>
                                        <li>Understanding of software testing and optimization
                                            methodologies</li>
                                        <li>Creating rich documentaion for software solutions</li>
                                        <li>Should be certified with internal Certificates if any
                                        </li>
                                    </ol>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>

            </div>
            <div className="row">
                <div className="col-md-6">
                    <a href="https://capgemini.sharepoint.com/sites/SkillFramework/Pages/Java.aspx">
                        <div className="btn tech-btn bg-primary text-white ml-3 mb-3">Express Interest
                        </div>
                    </a>
                </div>
                <div className="col-md-6 pr-5">
                    <div className="skill-header-inner pb-2"><b>Skill Framework Artefacts</b></div>
                    <table className="table pr-3">
                        <thead>
                            <tr>
                                <th scope="col">File Name</th>
                                <th scope="col">Download</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td><i className="float-left fas fa-file-pdf"
                                ></i><small><b><a
                                    href="https://capgemini.sharepoint.com/sites/SkillFramework/Shared%20Documents/Azure/20200115%20AZURE%20Skill%20Path-Roles.pdf"
                                >Azure
                                    SkillPath-Roles.pdf</a></b></small></td>
                                <td><a href="https://capgemini.sharepoint.com/sites/SkillFramework/Shared%20Documents/Azure/20200115%20AZURE%20Skill%20Path-Roles.pdf"
                                ><i
                                    className="text-primary fas fa-download"></i></a></td>

                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
}

export default DeveloperApps_AWS;