import React, { useState } from "react";
import { Accordion, Card } from "react-bootstrap";
import { useAccordionButton } from 'react-bootstrap/AccordionButton';
import AccordionRole from "./AccordionRole";
import DisplayRole from "./DisplayRole";
// import "./css_allstyles/sp-nav-edit1.css";
function CustomToggle({ children, eventKey }) {
    const decoratedOnClick = useAccordionButton(eventKey, () =>
        console.log('totally custom!'),
    );

    return (
        <div

            onClick={decoratedOnClick}
        >
            {children}
        </div>
        // { children }
    );
}
const Roles = () => {
    // const [expanded, setExpanded] = useState(false);
    return (
        // <AccordionRole />
        <div class="container-fluid" >
            <div class="tab-content" id="pills-tabContent">
                <div classname="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">
                    <div className="row">
                        <div class="col-md-4">
                            <div class="accordion md-accordion mb-5 mt-3 pt-5 sticky-top" id="accordionEx1" role="tablist"
                                aria-multiselectable="true">


                                <div class="card">

                                    {/* <div class="card-header" role="tab" >{/*id="headingTwo1">
                                        <a class="collapsed" data-toggle="collapse" data-parent="#accordionEx1"
                                            href="#collapseTwo1" aria-expanded="false" aria-controls="collapseTwo1">
                                            <h5 class="mb-0"> */}
                                    <DisplayRole />
                                    {/* </h5>
                                        </a>
                                    </div> */}
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    );
}

export default Roles;