import React, { useState } from "react";
import { Accordion, Card } from "react-bootstrap";
import { useAccordionButton } from 'react-bootstrap/AccordionButton';
import CloudFullStackDeveloperApps_AWS from "./CloudFullStackDeveloperApps_AWS";
import DeveloperApps_AWS from "./DeveloperApps_AWS";
import rolesMasterData from "./RoleMasterData";

// import "./css_allstyles/sp-nav-edit1.css";
function CustomToggle({ children, eventKey }) {
    const decoratedOnClick = useAccordionButton(eventKey, () =>
        console.log('totally custom!'),
    );

    return (
        <div

            onClick={decoratedOnClick}
        >
            {children}
        </div>
        // { children }
    );
}
const RolesWorking = () => {
    // const [expanded, setExpanded] = useState(false);
                                                    
    const[tabactiveshow,setTab]=useState("v-pills-home-tab-apps");
    return (
        <div class="container-fluid" >
            <div class="tab-content" id="pills-tabContent">
                <div classname="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">
                    <div className="row">
                        <div class="col-md-4">
                        <div class="accordion md-accordion mb-5 mt-3 pt-5 sticky-top" id="accordionEx1" role="tablist" aria-multiselectable="true">

                            <Accordion>
                                <Card>
                                    <Card.Header>
                                        <CustomToggle eventKey="0"><div className="card-header" role="tab" id="headingTwo1">
                                            <a className="collapsed" data-toggle="collapse" data-parent="#accordionEx1"
                                                href="#collapseTwo1" aria-expanded="false" aria-controls="collapseTwo1">
                                                <h5 className="mb-0">Apps Roles <i className="fas fa-angle-down rotate-icon"></i>
                                                </h5>
                                            </a>
                                        </div>
                                        </CustomToggle>
                                    </Card.Header>
                                    {/* <Accordion.Toggle eventKey="0"> */}


                                    {/* </Accordion.Toggle> */}
                                    <Accordion.Collapse eventKey="0">
                                        <Card.Body><div id="collapseTwo1" className="collapse show active" role="tabpanel"
                                            aria-labelledby="headingTwo1" data-parent="#accordionEx1">
                                            <div className="card-body">

                                                <div className="nav flex-column nav-pills" id="v-pills-tab" role="tablist"
                                                    aria-orientation="vertical">
                                                    <a className="nav-link" id="v-pills-messages-tab-apps" data-toggle="pill"
                                                     onClick={()=>setTab("v-pills-messages-tab-apps")}   href="#v-pills-messages-apps" role="tab"
                                                        aria-controls="v-pills-messages" aria-selected="false">AWS DevOps
                                                        Expert-Apps</a>
                                                    <a className="nav-link" id="v-pills-settings-tab-apps" data-toggle="pill"
                                                       onClick={()=>setTab("v-pills-settings-tab-apps")}   href="#v-pills-settings-apps" role="tab"
                                                        aria-controls="v-pills-messages" aria-selected="false">AWS Solution
                                                        Architect-Apps</a>
                                                    <a className="nav-link" id="v-pills-profile-tab-apps" data-toggle="pill"
                                                      onClick={()=>setTab("v-pills-profile-tab-apps")}    href="#v-pills-profile-apps" role="tab" aria-controls="v-pills-profile"
                                                        aria-selected="false">Cloud Full Stack Developer-Apps(AWS)</a>
                                                    <a className="nav-link" id="v-pills-home-tab-apps" data-toggle="pill"
                                                     onClick={()=>setTab("v-pills-home-tab-apps")}     href="#v-pills-home-apps" role="tab" aria-controls="v-pills-home"
                                                        aria-selected="true">Developer-Apps(AWS)</a>
                                                </div>

                                            </div>
                                        </div>
                                        </Card.Body>
                                    </Accordion.Collapse>
                                </Card>

                                <Card>
                                    <Card.Header>
                                        <CustomToggle eventKey="1"> <div className="card-header" role="tab" id="headingTwo2">
                                            <a className="collapsed" data-toggle="collapse" data-parent="#accordionEx1"
                                                href="#collapseTwo21" aria-expanded="false" aria-controls="collapseTwo21">
                                                <h5 className="mb-0">
                                                    Infra Roles <i className="fas fa-angle-down rotate-icon"></i>
                                                </h5>
                                            </a>
                                        </div>
                                        </CustomToggle>
                                    </Card.Header>

                                    <Accordion.Collapse eventKey="1">
                                        <Card.Body>
                                            <div id="collapseTwo21" className="collapse show active" role="tabpanel" aria-labelledby="headingTwo21"
                                                data-parent="#accordionEx1">
                                                <div className="card-body">

                                                    <div className="nav flex-column nav-pills" id="v-pills-tab" role="tablist"
                                                        aria-orientation="vertical">
                                                        <a className="nav-link" id="v-pills-settings-tab-infra" data-toggle="pill"
                                                        onClick={()=>setTab("v-pills-settings-tab-infra")}    href="#v-pills-settings-infra" role="tab"
                                                            aria-controls="v-pills-settings" aria-selected="false">AWS DevOps
                                                            Expert</a>
                                                        <a className="nav-link" id="v-pills-contacts-last-tab-infra" data-toggle="pill"
                                                         onClick={()=>setTab("v-pills-contacts-last-tab-infra")}   href="#v-pills-contacts-last-infra" role="tab"
                                                            aria-controls="v-pills-contacts-last" aria-selected="false">AWS Solution
                                                            Architect-Infra</a>
                                                        <a className="nav-link" id="v-pills-profile-tab-infra" data-toggle="pill"
                                                        onClick={()=>setTab("v-pills-profile-tab-infra")}    href="#v-pills-profile-infra" role="tab" aria-controls="v-pills-profile"
                                                            aria-selected="false">AWS Cloud SysOps Lead</a>
                                                        <a className="nav-link" id="v-pills-messages-tab-infra" data-toggle="pill"
                                                        onClick={()=>setTab("v-pills-messages-tab-infra")}    href="#v-pills-messages-infra" role="tab"
                                                            aria-controls="v-pills-messages" aria-selected="false">AWS DevOps
                                                            Analyst</a>
                                                        <a className="nav-link" id="v-pills-contacts-tab-infra" data-toggle="pill"
                                                        onClick={()=>setTab("v-pills-contacts-tab-infra")}    href="#v-pills-contacts-infra" role="tab"
                                                            aria-controls="v-pills-contacts" aria-selected="false">AWS Cloud
                                                            Architect</a>
                                                        <a className="nav-link" id="v-pills-home-tab-infra" data-toggle="pill"
                                                         onClick={()=>setTab("v-pills-home-tab-infra")}   href="#v-pills-home-infra" role="tab" aria-controls="v-pills-home"
                                                            aria-selected="true">AWS Cloud Engineer</a>
                                                    </div>

                                                </div>
                                            </div>
                                        </Card.Body>
                                    </Accordion.Collapse>
                                </Card>
                                <Card>
                                    <Card.Header>
                                        <CustomToggle eventKey="2">  <div className="card-header" role="tab" id="headingThree31">
                                            <a className="collapsed" data-toggle="collapse" data-parent="#accordionEx1"
                                                href="#collapseThree31" aria-expanded="false" aria-controls="collapseThree31">
                                                <h5 className="mb-0">
                                                    Data Roles <i className="fas fa-angle-down rotate-icon"></i>
                                                </h5>
                                            </a>
                                        </div>
                                        </CustomToggle>
                                    </Card.Header>

                                    <Accordion.Collapse eventKey="2">
                                        <Card.Body>
                                            <div id="collapseThree31" className="collapse show active" role="tabpanel"
                                                aria-labelledby="headingThree31" data-parent="#accordionEx1">
                                                <div className="card-body">

                                                    <div className="nav flex-column nav-pills" id="v-pills-tabs" role="tablist"
                                                        aria-orientation="vertical">
                                                        <a className="nav-link" id="v-pills-messages-tab-data" data-toggle="pill"
                                                          onClick={()=>setTab("v-pills-messages-tab-data")}   href="#v-pills-messages-data" role="tab"
                                                            aria-controls="v-pills-messages" aria-selected="false">Cloud Data
                                                            Scientist/Expert-Apps(AWS)</a>
                                                        <a className="nav-link" id="v-pills-settings-tab-data" data-toggle="pill"
                                                          onClick={()=>setTab("v-pills-settings-tab-data")}   href="#v-pills-settings-data" role="tab" aria-controls="v-psettings"
                                                            aria-selected="false">AWS Data Solution Architect</a>
                                                        <a className="nav-link" id="v-pills-profile-tab-data" data-toggle="pill"
                                                         onClick={()=>setTab("v-pills-profile-tab-data")}    href="#v-pills-profile-data" role="tab" aria-controls="v-pills-profile"
                                                            aria-selected="false">Senior Data Engineer / Data Engineering Lead</a>
                                                        <a className="nav-link" id="v-pills-home-tab-data" data-toggle="pill"
                                                         onClick={()=>setTab("v-pills-home-tab-data")}    href="#v-pills-home-data" role="tab" aria-controls="v-pills-home"
                                                            aria-selected="true">Data Engineer</a>
                                                    </div>

                                                </div>

                                            </div>
                                        </Card.Body>
                                    </Accordion.Collapse>
                                </Card>

                            </Accordion>
                            </div>
                            </div>
                        <div class="col-md-8 pt-5">
                            <div className="tab-content" id="v-pills-tabContent">
                                {/* <DeveloperApps_AWS /> */}
                                <div className={tabactiveshow==="v-pills-home-tab-apps"?"tab-pane fade show active":"tab-pane fade"} id="v-pills-home-apps" role="tabpanel"
            aria-labelledby="v-pills-home-tab-apps">
            <div className="card-body">
                <div className="tab-table table-responsive">
                    <table className="table">
                        <thead>
                            <tr>
                                {/*  {/* <!--      <th scope="col">#</th>--> */}
                                <td className="table-td"><b>Proficiency</b></td>
                                <td className="table-td">Beginner</td>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                {/*  {/* <!--      <th scope="row">1</th>--> */}
                                <td><b>Course Duration:</b></td>
                                <td>70+ hours</td>
                            </tr>
                            <tr>
                                {/*  {/* <!--      <th scope="row">2</th>--> */}
                                <td><b>Experience:</b></td>
                                <td>
                                    <ol>
                                        <li>Trained in these skills</li>
                                        <li>Conceptual knowledge across all</li>
                                        <li>0-2 years hands-on experience</li>
                                    </ol>
                                </td>
                            </tr>
                            <tr>
                                {/*  {/* <!--      <th scope="row">3</th>--> */}
                                <td><b>Employee Grade</b></td>
                                <td>A, B</td>
                            </tr>
                            <tr>
                                {/*  {/* <!--      <th scope="row">3</th>--> */}
                                <td><b>Professional Certification:</b></td>
                                <td>AZ 900 - Azure Foundation</td>
                            </tr>
                            <tr>
                                {/*  {/* <!--      <th scope="row">3</th>--> */}
                                <td><b>Internal Certification:</b><br />(Capgemini Standard
                                    Certification)</td>
                                <td>Not aplicable</td>
                            </tr>
                            <tr>
                                {/*  {/* <!--      <th scope="row">3</th>--> */}
                                <td><b>What will you learn?</b><br />(Mandatory skills)</td>
                                <td>
                                    <ol>
                                        <li>Programming Languages - e.g. C#, .net, .Net Core etc.
                                        </li>
                                        <li>JavaScript-Frameworks - e.g. Angular,React etc.</li>
                                        <li>Database Knowledge - e.g. SQL/NoSQL<br />RESTAPI</li>
                                        <li>Cloud Computing with the knowledge of any Public Cloud -
                                            e.e. Azure/AWS/Google</li>
                                        <li>Should be certified on Professional Certificate</li>
                                    </ol>
                                </td>
                            </tr>
                            <tr>
                                {/*  {/* <!--      <th scope="row">3</th>--> */}
                                <td><b>What will you learn?</b><br />(Good to Have Skills)</td>
                                <td>
                                    <ol>
                                        <li>Introduction to Cloud Migrations - Methodologies and
                                            tools</li>
                                        <li>TDD</li>
                                        <li>Microservices fundamentals</li>
                                        <li>Development Tools and IDE</li>
                                        <li>Knowledge of DevOps Tools</li>
                                        <li>Strong understanding of Agile development</li>
                                        <li>Understanding of software testing and optimization
                                            methodologies</li>
                                        <li>Creating rich documentaion for software solutions</li>
                                        <li>Should be certified with internal Certificates if any
                                        </li>
                                    </ol>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>

            </div>
            <div className="row">
                <div className="col-md-6">
                    <a href="https://capgemini.sharepoint.com/sites/SkillFramework/Pages/Java.aspx">
                        <div className="btn tech-btn bg-primary text-white ml-3 mb-3">Express Interest
                        </div>
                    </a>
                </div>
                <div className="col-md-6 pr-5">
                    <div className="skill-header-inner pb-2"><b>Skill Framework Artefacts</b></div>
                    <table className="table pr-3">
                        <thead>
                            <tr>
                                <th scope="col">File Name</th>
                                <th scope="col">Download</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td><i className="float-left fas fa-file-pdf"
                                ></i><small><b><a
                                    href="https://capgemini.sharepoint.com/sites/SkillFramework/Shared%20Documents/Azure/20200115%20AZURE%20Skill%20Path-Roles.pdf"
                                >Azure
                                    SkillPath-Roles.pdf</a></b></small></td>
                                <td><a href="https://capgemini.sharepoint.com/sites/SkillFramework/Shared%20Documents/Azure/20200115%20AZURE%20Skill%20Path-Roles.pdf"
                                ><i
                                    className="text-primary fas fa-download"></i></a></td>

                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
                                {/* <div><CloudFullStackDeveloperApps_AWS /></div> */}
                                <div className={tabactiveshow==="v-pills-profile-tab-apps"?"tab-pane fade show active":"tab-pane fade"} id="v-pills-profile-apps" role="tabpanel"
                                    aria-labelledby="v-pills-profile-tab-apps">

                                    <div className="card-body">
                                        <div className="tab-table table-responsive">

                                            <table className="table">
                                                <thead>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="col">#</th>--> */}

                                                        <td className="table-td"><b>Proficiency</b></td>
                                                        <td className="table-td">Beginner</td>

                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">1</th>--> */}
                                                        <td><b>Course Duration:</b></td>
                                                        <td>70+ hours</td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">2</th>--> */}
                                                        <td><b>Experience:</b></td>
                                                        <td>
                                                            <ol>
                                                                <li>Trained in these skills</li>
                                                                <li>Conceptual knowledge across all</li>
                                                                <li>0-2 years hands-on experience</li>
                                                            </ol>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">3</th>--> */}
                                                        <td><b>Employee Grade</b></td>
                                                        <td>A, B, c</td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">3</th>--> */}
                                                        <td><b>Professional Certification:</b></td>
                                                        <td>AZ 900 - Azure Foundation</td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">3</th>--> */}
                                                        <td><b>Internal Certification:</b><br />(Capgemini Standard
                                                            Certification)</td>
                                                        <td>Not aplicable</td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">3</th>--> */}
                                                        <td><b>What will you learn?</b><br />(Mandatory skills)</td>
                                                        <td>
                                                            <ol>
                                                                <li>Programming Languages - e.g. C#, .net, .Net Core etc.
                                                                </li>
                                                                <li>JavaScript-Frameworks - e.g. Angular,React etc.</li>
                                                                <li>Database Knowledge - e.g. SQL/NoSQL<br />RESTAPI</li>
                                                                <li>Cloud Computing with the knowledge of any Public Cloud -
                                                                    e.e. Azure/AWS/Google</li>
                                                                <li>Should be certified on Professional Certificate</li>
                                                            </ol>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">3</th>--> */}
                                                        <td><b>What will you learn?</b><br />(Good to Have Skills)</td>
                                                        <td>
                                                            <ol>
                                                                <li>Introduction to Cloud Migrations - Methodologies and
                                                                    tools</li>
                                                                <li>TDD</li>
                                                                <li>Microservices fundamentals</li>
                                                                <li>Development Tools and IDE</li>
                                                                <li>Knowledge of DevOps Tools</li>
                                                                <li>Strong understanding of Agile development</li>
                                                                <li>Understanding of software testing and optimization
                                                                    methodologies</li>
                                                                <li>Creating rich documentaion for software solutions</li>
                                                                <li>Should be certified with internal Certificates if any
                                                                </li>
                                                            </ol>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>

                                    </div>

                                </div>
                                <div className={tabactiveshow==="v-pills-messages-tab-apps"?"tab-pane fade show active":"tab-pane fade"} id="v-pills-messages-apps" role="tabpanel"
                                    aria-labelledby="v-pills-messages-tab-apps">

                                    <div className="card-body">
                                        <div className="tab-table table-responsive">

                                            <table className="table">
                                                <thead>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="col">#</th>--> */}

                                                        <td className="table-td"><b>Proficiency</b></td>
                                                        <td className="table-td">Beginner</td>

                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">1</th>--> */}
                                                        <td><b>Course Duration:</b></td>
                                                        <td>70+ hours</td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">2</th>--> */}
                                                        <td><b>Experience:</b></td>
                                                        <td>
                                                            <ol>
                                                                <li>Trained in these skills</li>
                                                                <li>Conceptual knowledge across all</li>
                                                                <li>0-2 years hands-on experience</li>
                                                            </ol>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">3</th>--> */}
                                                        <td><b>Employee Grade</b></td>
                                                        <td>A, B,d</td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">3</th>--> */}
                                                        <td><b>Professional Certification:</b></td>
                                                        <td>AZ 900 - Azure Foundation</td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">3</th>--> */}
                                                        <td><b>Internal Certification:</b><br />(Capgemini Standard
                                                            Certification)</td>
                                                        <td>Not aplicable</td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">3</th>--> */}
                                                        <td><b>What will you learn?</b><br />(Mandatory skills)</td>
                                                        <td>
                                                            <ol>
                                                                <li>Programming Languages - e.g. C#, .net, .Net Core etc.
                                                                </li>
                                                                <li>JavaScript-Frameworks - e.g. Angular,React etc.</li>
                                                                <li>Database Knowledge - e.g. SQL/NoSQL<br />RESTAPI</li>
                                                                <li>Cloud Computing with the knowledge of any Public Cloud -
                                                                    e.e. Azure/AWS/Google</li>
                                                                <li>Should be certified on Professional Certificate</li>
                                                            </ol>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">3</th>--> */}
                                                        <td><b>What will you learn?</b><br />(Good to Have Skills)</td>
                                                        <td>
                                                            <ol>
                                                                <li>Introduction to Cloud Migrations - Methodologies and
                                                                    tools</li>
                                                                <li>TDD</li>
                                                                <li>Microservices fundamentals</li>
                                                                <li>Development Tools and IDE</li>
                                                                <li>Knowledge of DevOps Tools</li>
                                                                <li>Strong understanding of Agile development</li>
                                                                <li>Understanding of software testing and optimization
                                                                    methodologies</li>
                                                                <li>Creating rich documentaion for software solutions</li>
                                                                <li>Should be certified with internal Certificates if any
                                                                </li>
                                                            </ol>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>

                                    </div>

                                </div>

                                <div className={tabactiveshow==="v-pills-settings-tab-apps"?"tab-pane fade show active":"tab-pane fade"} id="v-pills-settings-apps" role="tabpanel"
                                    aria-labelledby="v-pills-settings-tab-apps">

                                    <div className="card-body">

                                        <div className="table-heading pb-3"><b><span className="text-muted">Apps Roles</span> |
                                            Azure DevOps Expert</b></div>
                                        <div className="tab-table table-responsive">

                                            <table className="table">
                                                <thead>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="col">#</th>--> */}

                                                        <td className="table-td"><b>Proficiency</b></td>
                                                        <td className="table-td">Beginner</td>

                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">1</th>--> */}
                                                        <td><b>Course Duration:</b></td>
                                                        <td>70+ hours</td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">2</th>--> */}
                                                        <td><b>Experience:</b></td>
                                                        <td>
                                                            <ol>
                                                                <li>Trained in these skills</li>
                                                                <li>Conceptual knowledge across all</li>
                                                                <li>0-2 years hands-on experience</li>
                                                            </ol>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">3</th>--> */}
                                                        <td><b>Employee Grade</b></td>
                                                        <td>A, B,e</td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">3</th>--> */}
                                                        <td><b>Professional Certification:</b></td>
                                                        <td>AZ 900 - Azure Foundation</td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">3</th>--> */}
                                                        <td><b>Internal Certification:</b><br />(Capgemini Standard
                                                            Certification)</td>
                                                        <td>Not aplicable</td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">3</th>--> */}
                                                        <td><b>What will you learn?</b><br />(Mandatory skills)</td>
                                                        <td>
                                                            <ol>
                                                                <li>Programming Languages - e.g. C#, .net, .Net Core etc.
                                                                </li>
                                                                <li>JavaScript-Frameworks - e.g. Angular,React etc.</li>
                                                                <li>Database Knowledge - e.g. SQL/NoSQL<br />RESTAPI</li>
                                                                <li>Cloud Computing with the knowledge of any Public Cloud -
                                                                    e.e. Azure/AWS/Google</li>
                                                                <li>Should be certified on Professional Certificate</li>
                                                            </ol>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">3</th>--> */}
                                                        <td><b>What will you learn?</b><br />(Good to Have Skills)</td>
                                                        <td>
                                                            <ol>
                                                                <li>Introduction to Cloud Migrations - Methodologies and
                                                                    tools</li>
                                                                <li>TDD</li>
                                                                <li>Microservices fundamentals</li>
                                                                <li>Development Tools and IDE</li>
                                                                <li>Knowledge of DevOps Tools</li>
                                                                <li>Strong understanding of Agile development</li>
                                                                <li>Understanding of software testing and optimization
                                                                    methodologies</li>
                                                                <li>Creating rich documentaion for software solutions</li>
                                                                <li>Should be certified with internal Certificates if any
                                                                </li>
                                                            </ol>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>

                                    </div>

                                </div>


                                <div className={tabactiveshow==="v-pills-home-tab-infra"?"tab-pane fade show active":"tab-pane fade"} id="v-pills-home-infra" role="tabpanel"
                                    aria-labelledby="v-pills-home-tab-infra">

                                    <div className="card-body">
                                        <div className="tab-table table-responsive">

                                            <table className="table">
                                                <thead>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="col">#</th>--> */}

                                                        <td className="table-td"><b>Proficiency</b></td>
                                                        <td className="table-td">Beginner</td>

                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">1</th>--> */}
                                                        <td><b>Course Duration:</b></td>
                                                        <td>50+ hours</td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">2</th>--> */}
                                                        <td><b>Experience:</b></td>
                                                        <td>
                                                            <ol>
                                                                <li>Trained in these skills</li>
                                                                <li>Conceptual knowledge across all</li>
                                                                <li>0-2 years hands-on experience</li>
                                                            </ol>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">3</th>--> */}
                                                        <td><b>Employee Grade</b></td>
                                                        <td>A, B</td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">3</th>--> */}
                                                        <td><b>Professional Certification:</b></td>
                                                        <td>AZ 900 - Azure Foundation</td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">3</th>--> */}
                                                        <td><b>Internal Certification:</b><br />(Capgemini Standard
                                                            Certification)</td>
                                                        <td>Not aplicable</td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">3</th>--> */}
                                                        <td><b>What will you learn?</b><br />(Mandatory skills)</td>
                                                        <td>
                                                            <ol>
                                                                <li>Programming Languages - e.g. C#, .net, .Net Core etc.
                                                                </li>
                                                                <li>JavaScript-Frameworks - e.g. Angular,React etc.</li>
                                                                <li>Database Knowledge - e.g. SQL/NoSQL<br />RESTAPI</li>
                                                                <li>Cloud Computing with the knowledge of any Public Cloud -
                                                                    e.e. Azure/AWS/Google</li>
                                                                <li>Should be certified on Professional Certificate</li>
                                                            </ol>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">3</th>--> */}
                                                        <td><b>What will you learn?</b><br />(Good to Have Skills)</td>
                                                        <td>
                                                            <ol>
                                                                <li>Introduction to Cloud Migrations - Methodologies and
                                                                    tools</li>
                                                                <li>TDD</li>
                                                                <li>Microservices fundamentals</li>
                                                                <li>Development Tools and IDE</li>
                                                                <li>Knowledge of DevOps Tools</li>
                                                                <li>Strong understanding of Agile development</li>
                                                                <li>Understanding of software testing and optimization
                                                                    methodologies</li>
                                                                <li>Creating rich documentaion for software solutions</li>
                                                                <li>Should be certified with internal Certificates if any
                                                                </li>
                                                            </ol>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>

                                    </div>

                                </div>

                                <div className={tabactiveshow==="v-pills-profile-tab-infra"?"tab-pane fade show active":"tab-pane fade"} id="v-pills-profile-infra" role="tabpanel"
                                    aria-labelledby="v-pills-profile-tab-infra">

                                    <div className="card-body">
                                        <div className="tab-table table-responsive">

                                            <table className="table">
                                                <thead>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="col">#</th>--> */}

                                                        <td className="table-td"><b>Proficiency</b></td>
                                                        <td className="table-td">Beginner</td>

                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">1</th>--> */}
                                                        <td><b>Course Duration:</b></td>
                                                        <td>60+ hours</td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">2</th>--> */}
                                                        <td><b>Experience:</b></td>
                                                        <td>
                                                            <ol>
                                                                <li>Trained in these skills</li>
                                                                <li>Conceptual knowledge across all</li>
                                                                <li>0-2 years hands-on experience</li>
                                                            </ol>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">3</th>--> */}
                                                        <td><b>Employee Grade</b></td>
                                                        <td>A, B, c</td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">3</th>--> */}
                                                        <td><b>Professional Certification:</b></td>
                                                        <td>AZ 900 - Azure Foundation</td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">3</th>--> */}
                                                        <td><b>Internal Certification:</b><br />(Capgemini Standard
                                                            Certification)</td>
                                                        <td>Not aplicable</td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">3</th>--> */}
                                                        <td><b>What will you learn?</b><br />(Mandatory skills)</td>
                                                        <td>
                                                            <ol>
                                                                <li>Programming Languages - e.g. C#, .net, .Net Core etc.
                                                                </li>
                                                                <li>JavaScript-Frameworks - e.g. Angular,React etc.</li>
                                                                <li>Database Knowledge - e.g. SQL/NoSQL<br />RESTAPI</li>
                                                                <li>Cloud Computing with the knowledge of any Public Cloud -
                                                                    e.e. Azure/AWS/Google</li>
                                                                <li>Should be certified on Professional Certificate</li>
                                                            </ol>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">3</th>--> */}
                                                        <td><b>What will you learn?</b><br />(Good to Have Skills)</td>
                                                        <td>
                                                            <ol>
                                                                <li>Introduction to Cloud Migrations - Methodologies and
                                                                    tools</li>
                                                                <li>TDD</li>
                                                                <li>Microservices fundamentals</li>
                                                                <li>Development Tools and IDE</li>
                                                                <li>Knowledge of DevOps Tools</li>
                                                                <li>Strong understanding of Agile development</li>
                                                                <li>Understanding of software testing and optimization
                                                                    methodologies</li>
                                                                <li>Creating rich documentaion for software solutions</li>
                                                                <li>Should be certified with internal Certificates if any
                                                                </li>
                                                            </ol>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>

                                    </div>

                                </div>

                                <div className={tabactiveshow==="v-pills-messages-infra"?"tab-pane fade show active":"tab-pane fade"} id="v-pills-messages-infra" role="tabpanel"
                                    aria-labelledby="v-pills-messages-tab-infra">

                                    <div className="card-body">
                                        <div className="tab-table table-responsive">

                                            <table className="table">
                                                <thead>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="col">#</th>--> */}

                                                        <td className="table-td"><b>Proficiency</b></td>
                                                        <td className="table-td">Beginner</td>

                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">1</th>--> */}
                                                        <td><b>Course Duration:</b></td>
                                                        <td>90+ hours</td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">2</th>--> */}
                                                        <td><b>Experience:</b></td>
                                                        <td>
                                                            <ol>
                                                                <li>Trained in these skills</li>
                                                                <li>Conceptual knowledge across all</li>
                                                                <li>0-2 years hands-on experience</li>
                                                            </ol>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">3</th>--> */}
                                                        <td><b>Employee Grade</b></td>
                                                        <td>A, B,d</td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">3</th>--> */}
                                                        <td><b>Professional Certification:</b></td>
                                                        <td>AZ 900 - Azure Foundation</td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">3</th>--> */}
                                                        <td><b>Internal Certification:</b><br />(Capgemini Standard
                                                            Certification)</td>
                                                        <td>Not aplicable</td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">3</th>--> */}
                                                        <td><b>What will you learn?</b><br />(Mandatory skills)</td>
                                                        <td>
                                                            <ol>
                                                                <li>Programming Languages - e.g. C#, .net, .Net Core etc.
                                                                </li>
                                                                <li>JavaScript-Frameworks - e.g. Angular,React etc.</li>
                                                                <li>Database Knowledge - e.g. SQL/NoSQL<br />RESTAPI</li>
                                                                <li>Cloud Computing with the knowledge of any Public Cloud -
                                                                    e.e. Azure/AWS/Google</li>
                                                                <li>Should be certified on Professional Certificate</li>
                                                            </ol>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">3</th>--> */}
                                                        <td><b>What will you learn?</b><br />(Good to Have Skills)</td>
                                                        <td>
                                                            <ol>
                                                                <li>Introduction to Cloud Migrations - Methodologies and
                                                                    tools</li>
                                                                <li>TDD</li>
                                                                <li>Microservices fundamentals</li>
                                                                <li>Development Tools and IDE</li>
                                                                <li>Knowledge of DevOps Tools</li>
                                                                <li>Strong understanding of Agile development</li>
                                                                <li>Understanding of software testing and optimization
                                                                    methodologies</li>
                                                                <li>Creating rich documentaion for software solutions</li>
                                                                <li>Should be certified with internal Certificates if any
                                                                </li>
                                                            </ol>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>

                                    </div>

                                </div>

                                <div className={tabactiveshow==="v-pills-settings-tab-infra"?"tab-pane fade show active":"tab-pane fade"} id="v-pills-settings-infra" role="tabpanel"
                                    aria-labelledby="v-pills-settings-tab-infra">

                                    <div className="card-body">
                                        <div className="tab-table table-responsive">

                                            <table className="table">
                                                <thead>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="col">#</th>--> */}

                                                        <td className="table-td"><b>Proficiency</b></td>
                                                        <td className="table-td">Beginner</td>

                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">1</th>--> */}
                                                        <td><b>Course Duration:</b></td>
                                                        <td>80+ hours</td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">2</th>--> */}
                                                        <td><b>Experience:</b></td>
                                                        <td>
                                                            <ol>
                                                                <li>Trained in these skills</li>
                                                                <li>Conceptual knowledge across all</li>
                                                                <li>0-2 years hands-on experience</li>
                                                            </ol>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">3</th>--> */}
                                                        <td><b>Employee Grade</b></td>
                                                        <td>A, B,e</td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">3</th>--> */}
                                                        <td><b>Professional Certification:</b></td>
                                                        <td>AZ 900 - Azure Foundation</td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">3</th>--> */}
                                                        <td><b>Internal Certification:</b><br />(Capgemini Standard
                                                            Certification)</td>
                                                        <td>Not aplicable</td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">3</th>--> */}
                                                        <td><b>What will you learn?</b><br />(Mandatory skills)</td>
                                                        <td>
                                                            <ol>
                                                                <li>Programming Languages - e.g. C#, .net, .Net Core etc.
                                                                </li>
                                                                <li>JavaScript-Frameworks - e.g. Angular,React etc.</li>
                                                                <li>Database Knowledge - e.g. SQL/NoSQL<br />RESTAPI</li>
                                                                <li>Cloud Computing with the knowledge of any Public Cloud -
                                                                    e.e. Azure/AWS/Google</li>
                                                                <li>Should be certified on Professional Certificate</li>
                                                            </ol>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">3</th>--> */}
                                                        <td><b>What will you learn?</b><br />(Good to Have Skills)</td>
                                                        <td>
                                                            <ol>
                                                                <li>Introduction to Cloud Migrations - Methodologies and
                                                                    tools</li>
                                                                <li>TDD</li>
                                                                <li>Microservices fundamentals</li>
                                                                <li>Development Tools and IDE</li>
                                                                <li>Knowledge of DevOps Tools</li>
                                                                <li>Strong understanding of Agile development</li>
                                                                <li>Understanding of software testing and optimization
                                                                    methodologies</li>
                                                                <li>Creating rich documentaion for software solutions</li>
                                                                <li>Should be certified with internal Certificates if any
                                                                </li>
                                                            </ol>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>

                                    </div>

                                </div>


                                <div className={tabactiveshow==="v-pills-contacts-tab-infra"?"tab-pane fade show active":"tab-pane fade"} id="v-pills-contacts-infra" role="tabpanel"
                                    aria-labelledby="v-pills-contacts-tab-infra">

                                    <div className="card-body">
                                        <div className="tab-table table-responsive">

                                            <table className="table">
                                                <thead>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="col">#</th>--> */}

                                                        <td className="table-td"><b>Proficiency</b></td>
                                                        <td className="table-td">Beginner</td>

                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">1</th>--> */}
                                                        <td><b>Course Duration:</b></td>
                                                        <td>100+ hours</td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">2</th>--> */}
                                                        <td><b>Experience:</b></td>
                                                        <td>
                                                            <ol>
                                                                <li>Trained in these skills</li>
                                                                <li>Conceptual knowledge across all</li>
                                                                <li>0-2 years hands-on experience</li>
                                                            </ol>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">3</th>--> */}
                                                        <td><b>Employee Grade</b></td>
                                                        <td>A, B,e</td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">3</th>--> */}
                                                        <td><b>Professional Certification:</b></td>
                                                        <td>AZ 900 - Azure Foundation</td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">3</th>--> */}
                                                        <td><b>Internal Certification:</b><br />(Capgemini Standard
                                                            Certification)</td>
                                                        <td>Not aplicable</td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">3</th>--> */}
                                                        <td><b>What will you learn?</b><br />(Mandatory skills)</td>
                                                        <td>
                                                            <ol>
                                                                <li>Programming Languages - e.g. C#, .net, .Net Core etc.
                                                                </li>
                                                                <li>JavaScript-Frameworks - e.g. Angular,React etc.</li>
                                                                <li>Database Knowledge - e.g. SQL/NoSQL<br />RESTAPI</li>
                                                                <li>Cloud Computing with the knowledge of any Public Cloud -
                                                                    e.e. Azure/AWS/Google</li>
                                                                <li>Should be certified on Professional Certificate</li>
                                                            </ol>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">3</th>--> */}
                                                        <td><b>What will you learn?</b><br />(Good to Have Skills)</td>
                                                        <td>
                                                            <ol>
                                                                <li>Introduction to Cloud Migrations - Methodologies and
                                                                    tools</li>
                                                                <li>TDD</li>
                                                                <li>Microservices fundamentals</li>
                                                                <li>Development Tools and IDE</li>
                                                                <li>Knowledge of DevOps Tools</li>
                                                                <li>Strong understanding of Agile development</li>
                                                                <li>Understanding of software testing and optimization
                                                                    methodologies</li>
                                                                <li>Creating rich documentaion for software solutions</li>
                                                                <li>Should be certified with internal Certificates if any
                                                                </li>
                                                            </ol>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>

                                    </div>

                                </div>

                                <div className={tabactiveshow==="v-pills-home-tab-data"?"tab-pane fade show active":"tab-pane fade"} id="v-pills-home-data" role="tabpanel"
                                    aria-labelledby="v-pills-home-tab-data">

                                    <div className="card-body">
                                        <div className="tab-table table-responsive">

                                            <table className="table">
                                                <thead>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="col">#</th>--> */}

                                                        <td className="table-td"><b>Proficiency</b></td>
                                                        <td className="table-td">Beginner</td>

                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">1</th>--> */}
                                                        <td><b>Course Duration:</b></td>
                                                        <td>70+ hours</td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">2</th>--> */}
                                                        <td><b>Experience:</b></td>
                                                        <td>
                                                            <ol>
                                                                <li>Trained in these skills</li>
                                                                <li>Conceptual knowledge across all</li>
                                                                <li>0-2 years hands-on experience</li>
                                                            </ol>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">3</th>--> */}
                                                        <td><b>Employee Grade</b></td>
                                                        <td>Aaa, B</td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">3</th>--> */}
                                                        <td><b>Professional Certification:</b></td>
                                                        <td>AZ 900 - Azure Foundation</td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">3</th>--> */}
                                                        <td><b>Internal Certification:</b><br />(Capgemini Standard
                                                            Certification)</td>
                                                        <td>Not aplicable</td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">3</th>--> */}
                                                        <td><b>What will you learn?</b><br />(Mandatory skills)</td>
                                                        <td>
                                                            <ol>
                                                                <li>Programming Languages - e.g. C#, .net, .Net Core etc.
                                                                </li>
                                                                <li>JavaScript-Frameworks - e.g. Angular,React etc.</li>
                                                                <li>Database Knowledge - e.g. SQL/NoSQL<br />RESTAPI</li>
                                                                <li>Cloud Computing with the knowledge of any Public Cloud -
                                                                    e.e. Azure/AWS/Google</li>
                                                                <li>Should be certified on Professional Certificate</li>
                                                            </ol>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">3</th>--> */}
                                                        <td><b>What will you learn?</b><br />(Good to Have Skills)</td>
                                                        <td>
                                                            <ol>
                                                                <li>Introduction to Cloud Migrations - Methodologies and
                                                                    tools</li>
                                                                <li>TDD</li>
                                                                <li>Microservices fundamentals</li>
                                                                <li>Development Tools and IDE</li>
                                                                <li>Knowledge of DevOps Tools</li>
                                                                <li>Strong understanding of Agile development</li>
                                                                <li>Understanding of software testing and optimization
                                                                    methodologies</li>
                                                                <li>Creating rich documentaion for software solutions</li>
                                                                <li>Should be certified with internal Certificates if any
                                                                </li>
                                                            </ol>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>

                                    </div>

                                </div>

                                <div className={tabactiveshow==="v-pills-profile-tab-data"?"tab-pane fade show active":"tab-pane fade"} id="v-pills-profile-data" role="tabpanel"
                                    aria-labelledby="v-pills-profile-tab-data">

                                    <div className="card-body">
                                        <div className="tab-table table-responsive">

                                            <table className="table">
                                                <thead>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="col">#</th>--> */}

                                                        <td className="table-td"><b>Proficiency</b></td>
                                                        <td className="table-td">Beginner</td>

                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">1</th>--> */}
                                                        <td><b>Course Duration:</b></td>
                                                        <td>90+ hours</td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">2</th>--> */}
                                                        <td><b>Experience:</b></td>
                                                        <td>
                                                            <ol>
                                                                <li>Trained in these skills</li>
                                                                <li>Conceptual knowledge across all</li>
                                                                <li>0-2 years hands-on experience</li>
                                                            </ol>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">3</th>--> */}
                                                        <td><b>Employee Grade</b></td>
                                                        <td>Abc, B,d</td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">3</th>--> */}
                                                        <td><b>Professional Certification:</b></td>
                                                        <td>AZ 900 - Azure Foundation</td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">3</th>--> */}
                                                        <td><b>Internal Certification:</b><br />(Capgemini Standard
                                                            Certification)</td>
                                                        <td>Not aplicable</td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">3</th>--> */}
                                                        <td><b>What will you learn?</b><br />(Mandatory skills)</td>
                                                        <td>
                                                            <ol>
                                                                <li>Programming Languages - e.g. C#, .net, .Net Core etc.
                                                                </li>
                                                                <li>JavaScript-Frameworks - e.g. Angular,React etc.</li>
                                                                <li>Database Knowledge - e.g. SQL/NoSQL<br />RESTAPI</li>
                                                                <li>Cloud Computing with the knowledge of any Public Cloud -
                                                                    e.e. Azure/AWS/Google</li>
                                                                <li>Should be certified on Professional Certificate</li>
                                                            </ol>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">3</th>--> */}
                                                        <td><b>What will you learn?</b><br />(Good to Have Skills)</td>
                                                        <td>
                                                            <ol>
                                                                <li>Introduction to Cloud Migrations - Methodologies and
                                                                    tools</li>
                                                                <li>TDD</li>
                                                                <li>Microservices fundamentals</li>
                                                                <li>Development Tools and IDE</li>
                                                                <li>Knowledge of DevOps Tools</li>
                                                                <li>Strong understanding of Agile development</li>
                                                                <li>Understanding of software testing and optimization
                                                                    methodologies</li>
                                                                <li>Creating rich documentaion for software solutions</li>
                                                                <li>Should be certified with internal Certificates if any
                                                                </li>
                                                            </ol>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>

                                    </div>

                                </div>

                                <div className={tabactiveshow==="v-pills-messages-tab-data"?"tab-pane fade show active":"tab-pane fade"} id="v-pills-messages-data" role="tabpanel"
                                    aria-labelledby="v-pills-messages-tab-data">

                                    <div className="card-body">
                                        <div className="tab-table table-responsive">

                                            <table className="table">
                                                <thead>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="col">#</th>--> */}

                                                        <td className="table-td"><b>Proficiency</b></td>
                                                        <td className="table-td">Beginner</td>

                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">1</th>--> */}
                                                        <td><b>Course Duration:</b></td>
                                                        <td>90+ hours</td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">2</th>--> */}
                                                        <td><b>Experience:</b></td>
                                                        <td>
                                                            <ol>
                                                                <li>Trained in these skills</li>
                                                                <li>Conceptual knowledge across all</li>
                                                                <li>0-2 years hands-on experience</li>
                                                            </ol>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">3</th>--> */}
                                                        <td><b>Employee Grade</b></td>
                                                        <td>Abcd, B,d</td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">3</th>--> */}
                                                        <td><b>Professional Certification:</b></td>
                                                        <td>AZ 900 - Azure Foundation</td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">3</th>--> */}
                                                        <td><b>Internal Certification:</b><br />(Capgemini Standard
                                                            Certification)</td>
                                                        <td>Not aplicable</td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">3</th>--> */}
                                                        <td><b>What will you learn?</b><br />(Mandatory skills)</td>
                                                        <td>
                                                            <ol>
                                                                <li>Programming Languages - e.g. C#, .net, .Net Core etc.
                                                                </li>
                                                                <li>JavaScript-Frameworks - e.g. Angular,React etc.</li>
                                                                <li>Database Knowledge - e.g. SQL/NoSQL<br />RESTAPI</li>
                                                                <li>Cloud Computing with the knowledge of any Public Cloud -
                                                                    e.e. Azure/AWS/Google</li>
                                                                <li>Should be certified on Professional Certificate</li>
                                                            </ol>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">3</th>--> */}
                                                        <td><b>What will you learn?</b><br />(Good to Have Skills)</td>
                                                        <td>
                                                            <ol>
                                                                <li>Introduction to Cloud Migrations - Methodologies and
                                                                    tools</li>
                                                                <li>TDD</li>
                                                                <li>Microservices fundamentals</li>
                                                                <li>Development Tools and IDE</li>
                                                                <li>Knowledge of DevOps Tools</li>
                                                                <li>Strong understanding of Agile development</li>
                                                                <li>Understanding of software testing and optimization
                                                                    methodologies</li>
                                                                <li>Creating rich documentaion for software solutions</li>
                                                                <li>Should be certified with internal Certificates if any
                                                                </li>
                                                            </ol>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>

                                    </div>

                                </div>

                                <div className={tabactiveshow==="v-pills-settings-tab-data"?"tab-pane fade show active":"tab-pane fade"} id="v-pills-settings-data" role="tabpanel"
                                    aria-labelledby="v-pills-settings-tab-data">

                                    <div className="card-body">
                                        <div className="tab-table table-responsive">

                                            <table className="table">
                                                <thead>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="col">#</th>--> */}

                                                        <td className="table-td"><b>Proficiency</b></td>
                                                        <td className="table-td">Beginner</td>

                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">1</th>--> */}
                                                        <td><b>Course Duration:</b></td>
                                                        <td>90+ hours</td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">2</th>--> */}
                                                        <td><b>Experience:</b></td>
                                                        <td>
                                                            <ol>
                                                                <li>Trained in these skills</li>
                                                                <li>Conceptual knowledge across all</li>
                                                                <li>0-2 years hands-on experience</li>
                                                            </ol>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">3</th>--> */}
                                                        <td><b>Employee Grade</b></td>
                                                        <td>A11, B,d</td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">3</th>--> */}
                                                        <td><b>Professional Certification:</b></td>
                                                        <td>AZ 900 - Azure Foundation</td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">3</th>--> */}
                                                        <td><b>Internal Certification:</b><br />(Capgemini Standard
                                                            Certification)</td>
                                                        <td>Not aplicable</td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">3</th>--> */}
                                                        <td><b>What will you learn?</b><br />(Mandatory skills)</td>
                                                        <td>
                                                            <ol>
                                                                <li>Programming Languages - e.g. C#, .net, .Net Core etc.
                                                                </li>
                                                                <li>JavaScript-Frameworks - e.g. Angular,React etc.</li>
                                                                <li>Database Knowledge - e.g. SQL/NoSQL<br />RESTAPI</li>
                                                                <li>Cloud Computing with the knowledge of any Public Cloud -
                                                                    e.e. Azure/AWS/Google</li>
                                                                <li>Should be certified on Professional Certificate</li>
                                                            </ol>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        {/*  {/* <!--      <th scope="row">3</th>--> */}
                                                        <td><b>What will you learn?</b><br />(Good to Have Skills)</td>
                                                        <td>
                                                            <ol>
                                                                <li>Introduction to Cloud Migrations - Methodologies and
                                                                    tools</li>
                                                                <li>TDD</li>
                                                                <li>Microservices fundamentals</li>
                                                                <li>Development Tools and IDE</li>
                                                                <li>Knowledge of DevOps Tools</li>
                                                                <li>Strong understanding of Agile development</li>
                                                                <li>Understanding of software testing and optimization
                                                                    methodologies</li>
                                                                <li>Creating rich documentaion for software solutions</li>
                                                                <li>Should be certified with internal Certificates if any
                                                                </li>
                                                            </ol>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div >
                </div >
            </div >
        </div >
    );
}

export default RolesWorking;