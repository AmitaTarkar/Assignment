
import AccordionRole from './components/AccordionRole';
import NavBar from './components/NavBar';
import './css_allstyles/all.min.css';
import './css_allstyles/apply.css';
import './css_allstyles/bootstrap.min.css';
import './css_allstyles/grayscale.min.css';
import './css_allstyles/sp-nav-edit1.css';

function App() {
  return (
    <div>

      <NavBar />

      {/* <AccordionRole /> */}
    </div >
  );
}

export default App;
