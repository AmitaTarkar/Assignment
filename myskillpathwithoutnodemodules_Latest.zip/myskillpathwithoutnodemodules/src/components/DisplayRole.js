import React from 'react';
// import './App.css';
import rolesSelection from './RoleAccordData';
import AccordionRole from './AccordionRole';

function DisplayRole() {
    return (
        rolesSelection.map((e) => {
            return (
                // <AccordionRole name={e.name} id={e.id} roles={e.roles.map((a) => { return (a.rolename) })} />
                <AccordionRole name={e.name} id={e.id} />


            )
        })
    );
}

export default DisplayRole;