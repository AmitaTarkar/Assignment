import React, { useCallback, useState } from "react";
import AccordionRole from "./AccordionRole";
import DisplayRole from "./DisplayRole";
import LearningJourney from "./LearningJourney";
import Roles from "./Roles";
import RolesWorking from "./RolesWorking"

const NavBar = () => {
    const [navTo, setNav] = useState("LJ");
    // const [activeTab, setActiveTab] = useState("pills-home");
    const handleTab1 = (event) => {
        // update the state to tab1
        //setActiveTab("pills-home");

    };

    const handleTab2 = (event, id) => {
        // update the state to tab2

       // setActiveTab("pills-profile");
        // { 'pills-profile-tab'.className("nav-link active nav-journey") }

        //updateClass();
    };

    // const [activehref, className] = useState("pills-home-tab");

    // this.state = {
    //     className: 'a'
    // };

    // function updateClass() {
    //     let className = this.state.className;
    //     alert(className);
    //     // if (className === "nav-link nav-journey" ? "nav-link active nav-journey" : "nav-link nav-journey")
    //     //     //className = "nav-link active nav-journey"
    //     //     this.setState({ className });
    // }
    function CustomToggleHeader({ event }) {

    }
    return (
        <div class="tab-2 bg-white sticky-top mb-5">
            <ul class="nav ul-tab nav-pills justify-content-center sticky-top" id="pills-tab" role="tablist">

                <li className="nav-item mr-3" >
                {/* <li className="nav-item mr-3" onClick={handleTab1}> */}
                    <a className={navTo==="LJ"? "nav-link active nav-journey": "nav-link nav-journey"} 
                    id="pills-home-tab" data-toggle="pill" href="#pills-home"
                     onClick={() => setNav("LJ")}   role="tab" aria-controls="pills-home" aria-selected="true">Learning Journey
                    </a>

                </li>
                <li className="nav-item" >
                {/* <li className="nav-item" onClick={handleTab2}> */}
                    <a className={navTo==="Roles"? "nav-link active nav-journey": "nav-link nav-journey"} id="pills-profile-tab" data-toggle="pill" href="#pills-profile"
                     onClick={() => setNav("Roles")}   role="tab" aria-controls="pills-profile" aria-selected="false">Roles
                    </a>
                </li>
            </ul>
            <div className="outlet">
                {navTo === "LJ" ? <LearningJourney /> : <RolesWorking />}
                {/* {activeTab === "pills-home" ? <LearningJourney /> : <RolesWorking />} */}
                {/* {activeTab === "pills-home" ? <LearningJourney /> : <DisplayRole />} */}
                {/* {activehref === "pills-home-tab" ? { "a.className": "nav-link active nav-journey" } : { "a.className": "nav-link nav-journey" }} */}

                {/* if (activeTab)==="pills-home"{
                    <LearningJourney />

                }
                else{
                    <RolesWorking />
                } */}


            </div>
        </div>
    );
}

export default NavBar;